class info:

    def __init__(self):
        """This dunder method takes an input that whether you are an administrator or a customer and it has composition relation with two classes Administrator and Customer"""
        print('Enter 1 if you are administrator')
        print('Enter 2 if you are customer')
        try:
            user_or_administrator = int(input())
            if user_or_administrator == 1:
                administrator = Administrator()
            else:
                customer = Customer()
                customer.customer()

        except ValueError:
            print('invalid input')


class Administrator:
    __Password = 5674328

    def __init__(self):
        """This dunder method takes password as an input and then verify it.If it is valid then it gives administrator a hold on product file"""

        password = int(input('Enter the password'))
        if Administrator.__Password == password:
            print('you entered correct password')
            f = open('CS_21002_1.txt', 'r')
            f = f.read()

            self = eval(f)
            print('''
            Enter 1 or 2
            1_If you want to read all products
            2_If you want to write something in product file''')
            mode = int(input('Enter 1 or 2'))
            if mode == 2:
                print('''
                1_remove any product
                2_add any product
                3_change something in the product list''')


                admin = int(input('Enter 1 or 2 or 3'))
                if admin == 1:
                    print('All the products in the shop:')
                    for h in self:
                        print('-', h[0])
                    remove = input('Enter product name which you want remove')
                    remove = remove.upper()
                    for i in self:
                        if i[0] == remove:
                            self.remove(i)


                    print('*******PRODUCT HAS BEEN REMOVED SUCCESSFULLY:)*********')
                elif admin == 2:
                    product = input('Enter the product name')
                    product = product.upper()
                    price = int(input('Enter the price of that product'))
                    company = input('Enter the company name')
                    quantity = input('Enter quantity of that product')
                    self.append([product, price, company, quantity])
                    print('*******PRODUCT HAS BEEN ADDED SUCCESSFULLY:)*********')

                else:
                    print('''what type of change u want to make in the product
                    1_change in price
                    2_change in company's name
                    3_change in quantity''')
                    change = int(input('Enter 1 or 2 or 3 '))
                    product_name = input('Enter that product')
                    product_name = product_name.upper()
                    if change == 1:
                        correct_price = int(input('Enter correct price of the product'))

                        for i in self:
                            if i[0] == product_name:
                                i[1] = correct_price
                        print('*****PRICE OF THAT PRODUCT HAS*******')
                        print('***BEEN REPLACED WITH THE NEW PRICE:)*****')



                    elif change == 2:
                        correct_company = input('Enter correct company of that product')
                        for i in self:
                            if i[0] == product_name:
                                i[2] = correct_company
                        print('*****COMPANY OF THAT PRODUCT HAS*******')
                        print('***BEEN REPLACED WITH THE NEW COMPANY:)*****')

                    else:
                        correct_quantity = int(input('Enter quantity of that product'))

                        for i in self:
                            if i[0] == product_name:
                                i[3] = correct_quantity
                        print('*****QUANTITY OF THAT PRODUCT HAS*******')
                        print('***BEEN REPLACED WITH THE NEW QUANTITY:)*****')

                f = open('CS_21002_1.txt', 'w')
                f.write(str(self))

            else:
                for i in self:
                    print('Product:', i[0], '\tPrice:', i[1], '\tCompany:', i[2], '\tQuantity:', i[3])

        else:
            print('invalid password:(')


class Customer(list):
    def customer(self):
        """This method is calling method of this class"""

        self.customerinfo()

    def customerinfo(self):
        """This method calls a method and that method returns a list about 'customer's information and shopping cart' to the caller function.This customerinfo function after taking the list it calls check_out method"""
        i = Customer.information()
        self.Check_out(i)

    def Check_out(self, i):
        """This method takes customer list as an arguement print some information and then it confirms the shopping cart of the customer then it calls three functions"""
        print('Please check your data:')
        print('your email id', i[0])
        print('your name', i[1])
        print('your password', i[2])
        print('your Last name', i[3])
        print('your address', i[4])
        print('your city', i[5])
        print('''Today's Date''', i[6])
        print('Contact no:', i[8])

        print('You have selected all these products')
        for h in i[7]:
            print('Product', h[0])
            print('Quantity of that product', h[1])

        print('if you want to buy all these products press 1')

        print('otherwise press 2')
        wish = int(input())
        if wish == 1:
            p = i[0] + '.txt'
            self.append(i)#this append method inherits from list class and it appends the customer list in an empty list
            self.saveTofile(p)
            self.Check_bill(i)


        else:
            del (i)
            print('**your shopping cart has been removed successfully***:(')

    def saveTofile(self, Filename):
        """This method is taking file name as an arguement and it has a composition relation with FileSaver class and here self is an object contains customer list"""
        fs = FileSaver()
        fs.saveTofile(self, Filename)

    def Check_bill(self, i):
        """This method takes customer list as an arguement and it has a composition relation with Check_bill class"""
        check = Check_bill()
        check.Check_bill(i)

    def decorator(func):
        """A function decorator is coded on a line by itself just before the def statement that defines a function.my wrapper method read  all the products that are present in the product file and func() method calls information method and that method returns a customer list to func() and store in variable K then returns a list to the caller  """
        def mywrapper():

            f = open('CS_21002_1.txt', 'r')
            f = f.read()
            f = eval(f)
            for k in f:
                print('Product:', k[0], '\tPrice:', k[1], '\tCompany:', k[2], '\tQuantity:', k[3])
            k = func()
            return k

        return mywrapper

    @staticmethod
    @decorator
    def information():
        """fun() calls information() method.It takes customer's information and make his/her shopping cart, make a list and returns that list """
        s = []
        email = input('Enter your email id')
        n = input('Enter your name')
        n = n.upper()
        p = int(input('Enter the password'))

        l = input('Enter last name')
        address = input('Enter your address')
        city = input('Enter your city')
        date = input('Enter date')
        print('Enter how much products do u want to buy')
        count = int(input())
        for i in range(count):
            Shop = input('Enter what do you want')
            Shop = Shop.upper()
            Quantity = int(input('Enter the quantity'))
            s.append([Shop, Quantity])
        contact_no = int(input('Enter contact_no'))
        return [email, n, p, l, address, city, date, s, contact_no]


class FileReader:


    def readfromFile(self, fileName):
        """This method reads shopping history of customers"""
        f = open(fileName, 'r')
        f = f.read()
        print(['Email', 'Name', 'password', 'father name', 'address', 'city', 'date', '[product', 'quantity]',
               'contact no'])
        print(f)


class FileSaver:


    def saveTofile(self, obj, filename):
        """This method saves customer list in his/her individual shopping txt file """
        f = open(filename, 'a')
        for i in obj:
            f.write(str(i) + '\n')
        f.close()


class Check_bill:

    def Check_bill(self, i):
        """This method calculates the bill and asks him/her to watch shopping history and it has a composition relation with File Reader class"""
        bill = 0

        p = open('CS_21002_1.txt', 'r')

        p = p.read()
        l = eval(p)

        for k in i[7]:
            for j in l:
                if j[0] == k[0]:
                    other = j[1] * k[1]
                    bill = bill + other

                    @staticmethod
                    def _mul_(a, b):
                        return a * b

                    def _iadd_(a, b):
                        a = a + b
                        return a

        print('Your total bill is here', bill)
        print('Do you want to watch your shopping history')
        user = input('yes or no')
        user = user.upper()
        if user == 'YES':
            f = i[0] + '.txt'
            Open = FileReader()
            Open.readfromFile(f)

        print('************THANKS FOR COMING:)***************')


information = info()